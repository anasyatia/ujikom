@extends('layouts.app')

@section('title', 'Member')

@section('content')
<div class="container mx-auto p-6">
    <h1 class="text-2xl font-bold mb-4">Data Member</h1>

    <form action="{{ route('sales.member') }}" method="POST">
        @csrf

        @if (isset($member))
            <input type="hidden" name="member_id" value="{{ $member->id }}">
        @else
            <div class="mb-4">
                <label class="block font-semibold">Nama Member</label>
                <input type="text" name="nama" required class="border px-4 py-2 rounded w-full">
            </div>
            <div class="mb-4">
                <label class="block font-semibold">Nomor Telepon</label>
                <input type="text" name="telp" value="{{ $number_telephone }}" required class="border px-4 py-2 rounded w-full">
            </div>
        @endif

        <input type="hidden" name="total_harga" value="{{ $totalPrice }}">
        <input type="hidden" name="total_bayar" value="{{ $totalPaid }}">

        @foreach ($orders as $index => $order)
            <input type="hidden" name="orders[{{ $index }}][product_id]" value="{{ $order['product']->id }}">
            <input type="hidden" name="orders[{{ $index }}][quantity]" value="{{ $order['quantity'] }}">
        @endforeach

        <div class="mb-4">
            <label class="block font-semibold">Gunakan Point?</label>
            <label><input type="checkbox" name="use_point"> Gunakan {{ $point ?? 0 }} point</label>
        </div>

        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded">
            Selesaikan Pembelian
        </button>
    </form>
</div>
@endsection
